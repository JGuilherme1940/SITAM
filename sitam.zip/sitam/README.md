# SITAM — Sistema Integrado de Transporte e Abastecimento Multinacional

Protótipo navegável do app, feito em HTML, CSS e JavaScript puro (sem
frameworks, sem instalação de dependências). Pensado pra rodar direto no
VS Code e ser apresentado na feira de empreendedorismo.

## Como abrir no VS Code

1. Extraia a pasta `sitam` e abra ela no VS Code (`Arquivo → Abrir Pasta`).
2. Instale a extensão **Live Server** (de Ritwick Dey), se ainda não tiver.
3. Clique com o botão direito em `index.html` → **Open with Live Server**.
4. O navegador abre a landing page, e você navega pelo app normalmente.

Se não quiser instalar extensão nenhuma, também dá pra simplesmente abrir o
arquivo `index.html` duas vezes clicando nele — funciona, mas o Live Server
recarrega a página sozinho a cada alteração, o que ajuda bastante na hora de
ajustar coisas antes da apresentação.

## Estrutura de arquivos

```
sitam/
├── index.html                    # landing page / apresentação do produto
├── cadastro.html                 # cadastro (caminhoneiro OU pessoa/empresa)
├── dashboard-caminhoneiro.html   # painel de quem transporta
├── dashboard-cliente.html        # painel de quem contrata o transporte
├── css/style.css                 # toda a identidade visual (branco e vermelho)
└── js/script.js                  # interatividade das telas
```

## O que já funciona (simulado, sem back-end)

- Cadastro com escolha entre **caminhoneiro** e **pessoa/organização**,
  cada um com campos próprios (a tela muda dinamicamente).
- Painel do caminhoneiro com lista de fretes disponíveis e botão de aceitar.
- Painel do cliente com formulário de solicitação, cálculo automático de
  valor estimado (por distância + peso) e lista de caminhoneiros disponíveis.
- Linha do tempo de status do pedido: Solicitado → Aceito → Em trânsito →
  Entregue.

Tudo isso usa dados fixos no `script.js` — é um protótipo de interface, não
um sistema com banco de dados de verdade. É proposital: pra feira, o que
importa é mostrar a experiência completa do app funcionando.

## Ideias para evoluir (bom material pra banca de avaliação)

Se quiser mostrar que pensou além do protótipo visual, vale citar na
apresentação:

- **Back-end real**: Node.js + Express (ou Firebase) com banco de dados
  (PostgreSQL ou MongoDB) pra cadastro, pedidos e histórico persistirem.
- **Geolocalização real**: API do Google Maps ou Mapbox pra calcular
  distância e rota de verdade, em vez do valor simulado.
- **Notificações**: push notification quando um caminhoneiro aceita um
  frete, ou quando o status muda.
- **Pagamento integrado**: split de pagamento entre a plataforma e o
  caminhoneiro (ex: comissão de X% por frete concluído).
- **Verificação de documentos**: validação de CNH e antecedentes do
  motorista antes da liberação da conta, pra segurança.
- **Chat dentro do app**: comunicação direta entre cliente e caminhoneiro
  durante o trajeto.
- **Modelo de negócio**: comissão por frete, plano de assinatura mensal
  para empresas que fazem muitos envios, ou taxa fixa por publicação.

## Paleta e identidade

- Vermelho principal: `#C4241C`
- Branco/papel: `#FAF8F5`
- Preto/tinta: `#1B1815`
- Amarelo-alerta (uso pontual, tipo sinalização): `#E8A93A`

A tipografia usa uma fonte condensada (Bebas Neue) nos títulos, remetendo a
placas e sinalização rodoviária — reforça visualmente que o produto é sobre
estrada e transporte.
